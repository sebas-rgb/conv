print("¿Qué tipo de base tiene el número?")
print("1. Decimal\n2. Binario\n3. Octal\n4. Hexadecimal")
select = int(input())

if select == 1:
    print("Ingrese el número (decimal) separado por espacios")
    entrada = input()
    numeros_str = entrada.split() 
    num_dec = [int(num) for num in numeros_str]  
    
    print("A qué base lo quiere pasar?")
    print("1. Binario")
    print("2. Octal")
    print("3. Hexadecimal")
    select2 = int(input())
    
    if select2 == 1:
        
        binario = [bin(numero)[2:] for numero in num_dec]
        print("ASCii")  
        for numero, binario_numero in zip(num_dec, binario):
            caracter = chr(numero)
            print(f"{caracter}")
        print("\nbinario",binario)
        
    elif select2 == 2:
        
        octal= [oct(numero)[2:] for numero in num_dec]

        print("ASCii")
        for numero, octal_numero in zip(num_dec, octal):
            caracter = chr(numero)
            print(f"{caracter}")

        binario =[ bin(numero)[2:] for numero in num_dec]
        print("\noctales",octal)
        print("\nBinario:",binario)
        

    elif select2 == 3:
        hexd = [hex(numero)[2:] for numero in num_dec]  

        print("ASCii")
        for numero, hexd_numero in zip(num_dec, hexd):
            caracter = chr(numero)
            print(f" {caracter}")

        binario =[ bin(numero)[2:] for numero in num_dec]
        print("\nBinarios",binario)

        print("\nHexadecimales:",hexd)
      
    else:
        print("Error")
      
elif select == 2:
    
    print("Ingrese el número (binario) separado por espacios")
    entrada = input()
    numeros_str = entrada.split() 
    num_bin = [int(num) for num in numeros_str]
 
    print("A qué base lo quiere pasar?")
    print("1. Decimal")
    print("2. Octal")
    print("3. Hexadecimal")
    select2 = int(input())
    
    if select2 == 1:
        decimal = [int(binario, 2) for binario in numeros_str]

        print("ASCii")
        for dec, binario in zip(decimal, num_bin):
         caracter = chr(dec)
         print(f"{caracter}")

        binario =[ bin(numero)[2:] for numero in decimal]
        print("\nBinario",binario)

        print("\nDecimales:",decimal)

    elif select2 == 2:
         decimal = [int(binario, 2) for binario in numeros_str]

         print("ASCii")
         for dec, binario in zip(decimal, num_bin):
          caracter = chr(dec)
          print(f"{caracter}")

         binario =[ bin(numero)[2:] for numero in decimal]
         octal =[oct(decimal)[2:] for decimal in decimal]

         print("\nBinario",binario)
         print("\nmOctales:",octal)

    elif select2 == 3:
         decimal = [int(binario, 2) for binario in numeros_str]

         print("ASCii")
         for dec, binario in zip(decimal, num_bin):
          caracter = chr(dec)
          print(f"{caracter}")

         binario =[ bin(numero)[2:] for numero in decimal]
         hexa =[hex(decimal)[2:] for decimal in decimal]

         print("\nBinario",binario)
         print("\nHexadecimales:",hexa)
         
    else:
        print("Error")

elif select == 3:
    print("Ingrese el número (octal) separado por espacios")
    entrada = input()
    numeros_str = entrada.split() 
    num_oct = [int(num,8) for num in numeros_str]
    
    print("A qué base lo quiere pasar?")
    print("1. Binario")
    print("2. Decimal")
    print("3. Hexadecimal")
    select2 = int(input())
    
    if select2 == 1:
        
        decimal = [int(octagonal, 8) for octagonal in numeros_str]

        print("ASCII:")
        for dec, octagonal in zip(decimal, num_oct):
          caracter = chr(dec)
          print(f"{caracter}")

        binario = [bin(num)[2:] for num in decimal]
        print("\nBinarios:",binario)
        

    elif select2 == 2:
         
        decimal = [int(octagonal, 8) for octagonal in numeros_str]

        print("ASCII:")
        for dec, octagonal in zip(decimal, num_oct):
          caracter = chr(dec)
          print(f"{caracter}")

        print("\nDecimales:",decimal)

        binario = [bin(num)[2:] for num in decimal]
        print("\nBinarios:",binario)

    elif select2 == 3:
         decimal = [int(octagonal, 8) for octagonal in numeros_str]

         print("ASCII:")
         for dec, octagonal in zip(decimal, num_oct):
          caracter = chr(dec)
          print(f"{caracter}")
        
         hexadecimal =[hex(num)[2:] for num in decimal]
         print("\nHexadecimales:",hexadecimal)

         binario = [bin(num)[2:] for num in decimal]
         print("\nBinarios:",binario)
    else:
        print("Error")

elif select == 4:
    print("Ingrese el número (hexadecimal) separado por espacios")
    entrada = input()
    numeros_str = entrada.split() 
    num_hex = [int(num,16) for num in numeros_str] 
    
    print("A qué base lo quiere pasar?")
    print("1. Binario")
    print("2. Octal")
    print("3. Decimal")
    select2 = int(input())
    
    if select2 == 1:
        decimal = [int(hexa, 16) for hexa in numeros_str]

        print("ASCII:")
        for dec, octagonal in zip(decimal, num_hex):
          caracter = chr(dec)
          print(f"{caracter}")

        binario = [bin(num)[2:] for num in decimal]
        print("\nBinarios:",binario)

    elif select2 == 2:
        decimal = [int(hexa, 16) for hexa in numeros_str]

        print("\nASCII:")
        for dec, octagonal in zip(decimal, num_hex):
          caracter = chr(dec)
          print(f"{caracter}")

        Octal = [oct(octi)[2:] for octi in decimal]
        print("\noctales:",Octal)

        binario = [bin(num)[2:] for num in decimal]
        print("\nBinarios:",binario)

    elif select2 == 3:
         decimal = [int(hexa, 16) for hexa in numeros_str]

         print("\nASCII:")
         for dec, octagonal in zip(decimal, num_hex):
          caracter = chr(dec)
          print(f"{caracter}")

         print("\nDecimales:",decimal)

         binario = [bin(num)[2:] for num in decimal]
         print("\nBinarios:",binario)
    else:
        print("Error")

else:
    print("Opción no válida. Por favor, elige una opción válida.")